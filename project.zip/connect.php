<?php

//database_connection.php

$connect = new PDO("mysql:host=localhost;dbname=id11885337_chat", "id11885337_chat", "kusuma1234680",);

?>
